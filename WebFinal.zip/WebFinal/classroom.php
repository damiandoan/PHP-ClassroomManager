<?php
 require('database.php');
 session_start();
    if (!isset($_SESSION['fullname'])){
        header( "Location: login.php");
        exit();
    }
if(isset($_POST['go-to-classroom'])){
      $param = explode('<*>', $_POST['go-to-classroom']);
      $_SESSION['teacher_email'] = $param[0];
      $_SESSION['classroom_name']= $param[1];
    }
if(!isset($_SESSION['classroom_name'])){
        header('location: homepage.php');
}
$classroom_name = $_SESSION['classroom_name'];
$teacher_email = $_SESSION['teacher_email'];

if(isset($_POST['submit-add-student-form'])){
  $alert =add_student($classroom_name, $teacher_email, $_POST['student_ID'], $_POST['first_name'], $_POST['last_name'], $_POST['student_email']);
  header('Location: '.$_SERVER["PHP_SELF"], true, 303);
}
if(isset($_POST['submit-import-students-form'])){
  import_students_from_csv($classroom_name, $teacher_email);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title><?=$classroom_name?> </title>
</head>
<body>





<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">
  <h1  ><?=$classroom_name?></h1>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <button class="btn btn-primary"  type = 'submit' data-toggle="modal" data-target="#add-student-modal-box" data-whatever="@mdo" >Add student</a>
      </li>
      <li class="nav-item">
      <button class="btn text-white bg-success" type = 'submit' data-toggle="modal" data-target="#import-students-modal" data-whatever="@mdo" >Import students</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>
       <!-- Dropdown -->
    <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Dropdown link
    </a>
    <div class="dropdown-menu">
        <a class="dropdown-item" href="#">Link 1</a>
        <a class="dropdown-item" href="#">Link 2</a>
        <a class="dropdown-item" href="#">Link 3</a>
    </div>
    </li>    
    </ul>
  </div>  
</nav>

<div class = 'container'>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Student ID</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
  <?php 
    $sql = 'SELECT student.student_ID, student.first_name, student.last_name, student.email FROM student, take_course WHERE take_course.teacher_email like ? and take_course.classroom_name like ? and student.student_Id = take_course.student_ID';
    $connection = create_connection();
    $stmt = $connection->prepare($sql);
    
    $stmt->bind_param('ss', $teacher_email,$classroom_name);
      if($stmt->execute()){
     
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
          // output data of each row
          $i=1;
          while($row = $result->fetch_assoc()) {
            
            ?>
            <tr>
              <th scope="row"><?=$i?></th>
              <td><?=$row['first_name']?></td>
              <td><?=$row['last_name']?></td>
              <td><?=$row['student_ID']?></td>
              <td><?=$row['email']?></td>
            </tr>
            <?php
            $i++;
          }
  
        }
  
   } 
   $connection->close();
  
  ?>
   </tbody>
</table>
</div>


<div class="modal fade " id="add-student-modal-box" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content bg-light">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add student to <?=$classroom_name?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="classroom.php" method="post" class="form-horizontal" role="form" id = 'add-student-form' enctype="multipart/form-data">


              <div class="form-group">
                  <label for="name" class="col-sm-3 control-label">First name</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="first_name">
                  </div>
              </div> <!-- form-group // -->

              <div class="form-group">
                  <label for="name" class="col-sm-3 control-label">Last name</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="last_name" >
                  </div>
              </div> <!-- form-group // -->
              <div class="form-group">
                  <label for="name" class="col-sm-3 control-label">Student ID</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="student_ID" >
                  </div>
              </div> <!-- form-group // -->

              <div class="form-group">
                  <label for="name" class="col-sm-3 control-label">Email</label>
                  <div class="col-sm-9">
                  <input type="text" class="form-control" name="student_email" >
                  </div>
              </div> <!-- form-group // -->

              

            
      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name = 'submit-add-student-form' form = 'add-student-form' class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>



<div class="modal fade " id="import-students-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content bg-light">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Import student from csv to <?=$classroom_name?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="classroom.php" method="post" class="form-horizontal" role="form" id = 'import-students-form' enctype="multipart/form-data">
      <label for="formFileMultiple" class="form-label"> use csv file with studentID, first name, last name, email in each line format! :</label>
      <input class="form-control btn-light" type="file"  name="student list file"  accept=".csv" >
      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name = 'submit-import-students-form' form = 'import-students-form' class="btn btn-primary">Import</button>
      </div>
    </div>
  </div>
</div>

<p><?=$alert?></p>
</body>
</html>