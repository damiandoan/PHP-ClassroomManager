function reset_password_popup(){
    window.open('reset_password.php','popup','width=600,height=600')
}



