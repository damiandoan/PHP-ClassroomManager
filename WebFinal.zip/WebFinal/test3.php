<?php
function add_students_from_csv(){
if (($handle = fopen("StudentList.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        
    }
    fclose($handle);
}
}
?>